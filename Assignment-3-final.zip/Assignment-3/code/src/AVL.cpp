// Provide your implementation for the AVLIndex class here
#include "AVL.hpp"
#include <algorithm>

AVLIndex::AVLIndex() : BSTIndex() {}
//Returns 0 for null, otherwise the stored height field.
int AVLIndex::getHeight(TreeNode* node) const {
    return node ? node->height : 0;
}
// Update stored height from children 
void AVLIndex::updateHeight(TreeNode* node) {
    if (node)
        node->height = 1 + max(getHeight(node->left), getHeight(node->right));
}
// finds the balance factor, if positive so left heavy otherwise right heavy and if -1,0, +1 then balanced, hence AVL tree
int AVLIndex::getBalance(TreeNode* node) const {
    return node ? getHeight(node->left) - getHeight(node->right) : 0;
}

// rigth rotates when the left subtree is too tall to balance, left child becomes the new root 
TreeNode* AVLIndex::rotateRight(TreeNode* y) {
    TreeNode* x = y->left;
    TreeNode* B = x->right;
    x->right = y;
    y->left  = B;
    updateHeight(y);  // y is now lower; must be updated first
    updateHeight(x);
    return x;  // x is the new subtree root
}

// Used when the right subtree is too tall
TreeNode* AVLIndex::rotateLeft(TreeNode* x) {
    TreeNode* y = x->right;
    TreeNode* B = y->left;
    y->left  = x;
    x->right = B;
    updateHeight(x);  // x is now lower so it must be updated first
    updateHeight(y);
    return y;  // y is the new subtree root
}

TreeNode* AVLIndex::avlInsert(TreeNode* node, const string& key, int idx) {
    if (!node) return new TreeNode(key, idx);
    if (key < node->key) {
        node->left  = avlInsert(node->left,  key, idx);
    } else if (key > node->key) {
        node->right = avlInsert(node->right, key, idx);
    } else {
        // Duplicate key: add the index to the existing node; tree stays balanced
        node->indices.push_back(idx);
        return node;
    }
    updateHeight(node);
    int bal = getBalance(node); // rebalance if needed 
    // LL Case: left subtree is heavy and new key went further left, so single rigth rotation needed
    if (bal > 1 && key < node->left->key)
        return rotateRight(node);
    // RR Case: right subtree is heavy AND new key went further right, single left rotation needed 
    if (bal < -1 && key > node->right->key)
        return rotateLeft(node);
    // LR Case: left subtree is heavy AND new key went into its right side
    // left-rotate the left child first, then right-rotate this node
    if (bal > 1 && key > node->left->key) {
        node->left = rotateLeft(node->left);
        return rotateRight(node);
    }
    // RL Case: right subtree is heavy AND new key went into its left side
    // right-rotate the right child first, then left-rotate this node
    if (bal < -1 && key < node->right->key) {
        node->right = rotateRight(node->right);
        return rotateLeft(node);
    }
    return node;
TreeNode* AVLIndex::insertNode(TreeNode* node,
                                const string& key, int idx) {
    return avlInsert(node, key, idx);
}
void AVLIndex::Add(const int i, const string& Key) {
    root = avlInsert(root, Key, i);
}