// Provide the function signature for the AVLIndex class here
#ifndef AVL_HPP
#define AVL_HPP

#include "BST.hpp"

class AVLIndex : public BSTIndex {
private:
    int  getHeight(TreeNode* node) const;
    void updateHeight(TreeNode* node);
    int  getBalance(TreeNode* node) const;

    TreeNode* rotateRight(TreeNode* y);
    TreeNode* rotateLeft(TreeNode* x);
    TreeNode* avlInsert(TreeNode* node, const string& key, int idx);

protected:
    TreeNode* insertNode(TreeNode* node, const string& key, int idx) override;

public:
    AVLIndex();
    void Add(const int i, const string& Key) override;
};

#endif