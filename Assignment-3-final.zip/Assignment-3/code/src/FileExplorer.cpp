// Provide your implementation for the FileExplorer class here
#include "FileExplorer.hpp"

#include <algorithm>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

using namespace std;
FileExplorer::FileExplorer(const string& type, const string& csv_file) {
    fs = new FileSystem();
    fs->LoadFilesFromCsv(csv_file);
    if (type == "AVL") {
        NameIndex = new AVLIndex();
        DateIndex = new AVLIndex();
    } else {  // "BST" (default)
        NameIndex = new BSTIndex();
        DateIndex = new BSTIndex();
    }
    NameIndex->CreateIndex(fs->entries, "FileName");
    DateIndex->CreateIndex(fs->entries, "lastModifiedOn");
}
FileExplorer::~FileExplorer() {
    delete NameIndex;
    delete DateIndex;
    delete fs;
}
static void writeOutput(const vector<int>& indices,
                        int                nodesVisited,
                        const string&      outputPath,
                        const FileSystem*  fsys) {
    ofstream out(outputPath);
    if (!out.is_open()) {
        cerr << "Cannot open: " << outputPath << "\n";
        return;
    }
    out << "Number of nodes traversed: " << nodesVisited << "\n";
    for (int idx : indices)
        out << fsys->entries[idx].path << "\n";
}
void FileExplorer::FindByName(const string& filename,
                               const string& output_path) {
    auto [indices, nodes] = NameIndex->Search(filename);
    writeOutput(indices, nodes, output_path, fs);
}
void FileExplorer::FindByDate(const string& date,
                               const string& output_path) {
    auto [indices, nodes] = DateIndex->Search(date);
    writeOutput(indices, nodes, output_path, fs);
}
void FileExplorer::FindByNameAndDate(const string& filename,
                                      const string& date,
                                      const string& output_path) {
    auto [nameIdx, nameNodes] = NameIndex->Search(filename);
    auto [dateIdx, dateNodes] = DateIndex->Search(date);

    sort(nameIdx.begin(), nameIdx.end());
    sort(dateIdx.begin(), dateIdx.end());

    vector<int> common;
    set_intersection(nameIdx.begin(), nameIdx.end(),
                     dateIdx.begin(), dateIdx.end(),
                     back_inserter(common));

    writeOutput(common, nameNodes + dateNodes, output_path, fs);
}
void FileExplorer::FindByNameAndSize(const string& filename,
                                      const int     size,
                                      const string& output_path) {
    auto [indices, nodes] = NameIndex->Search(filename);

    vector<int> filtered;
    for (int idx : indices)
        if (fs->entries[idx].Size == size)
            filtered.push_back(idx);

    writeOutput(filtered, nodes, output_path, fs);
}
void FileExplorer::FindFilesCreatedDuring(const string& date1,
                                           const string& date2,
                                           const string& output_path) {
    auto [indices, nodes] = DateIndex->SearchRange(date1, date2);
    writeOutput(indices, nodes, output_path, fs);
}