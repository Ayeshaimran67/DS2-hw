// Provide the function signature for the BSTIndex class here
#ifndef BST_HPP
#define BST_HPP

#include "FileSystem.hpp"
#include <string>
#include <utility>
#include <vector>

using namespace std;

struct TreeNode {
    string      key;
    vector<int> indices;
    TreeNode*   left;
    TreeNode*   right;
    int         height;

    TreeNode(const string& k, int idx)
        : key(k), left(nullptr), right(nullptr), height(1) {
        indices.push_back(idx);
    }
};

class BSTIndex {
protected:
    TreeNode* root;

    virtual TreeNode* insertNode(TreeNode* node, const string& key, int idx);

    void collectRange(TreeNode* node, const string& lo, const string& hi,
                      vector<int>& results, int& nodesVisited) const;

    void destroy(TreeNode* node);

public:
    BSTIndex();
    virtual ~BSTIndex();

    void CreateIndex(vector<FileSystemEntry>& Data, const string& IndexType);

    virtual void Add(const int i, const string& Key);

    pair<vector<int>, int> Search(const string& Key) const;

    pair<vector<int>, int> SearchRange(const string& lo, const string& hi) const;

    TreeNode* getRoot() const { return root; }
};

#endif