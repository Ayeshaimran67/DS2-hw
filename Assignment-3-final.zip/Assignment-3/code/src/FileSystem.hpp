#pragma once

#include <ctime>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <sstream>
#include <vector>

using namespace std;

struct FileSystemEntry {
    string Filename;
    int    Size;
    string accessedOn;
    string modifiedOn;
    string Type;
    string path;
};

class FileSystem {
public:

    vector<FileSystemEntry> entries;

    void   LoadFilesFromCsv(const string &csv_file);
    string ParseTimestamp(const string &timestampStr);
    void   PrintFileEntry();
};