// Provide your implementation for the FileExplorer class here
#include "FileExplorer.hpp"

#include <algorithm>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

using namespace std;

// ─────────────────────────────────────────────────────────────────────────────
// Constructor
//   Loads the CSV, then builds two indexes of the requested type.
//     NameIndex → keyed on Filename
//     DateIndex → keyed on modifiedOn (already YYYY-MM-DD via ParseTimestamp)
// ─────────────────────────────────────────────────────────────────────────────
FileExplorer::FileExplorer(const string& type, const string& csv_file) {
    fs = new FileSystem();
    fs->LoadFilesFromCsv(csv_file);

    if (type == "AVL") {
        NameIndex = new AVLIndex();
        DateIndex = new AVLIndex();
    } else {  // "BST" (default)
        NameIndex = new BSTIndex();
        DateIndex = new BSTIndex();
    }

    NameIndex->CreateIndex(fs->entries, "FileName");
    DateIndex->CreateIndex(fs->entries, "lastModifiedOn");
}

// ─────────────────────────────────────────────────────────────────────────────
// Destructor
// ─────────────────────────────────────────────────────────────────────────────
FileExplorer::~FileExplorer() {
    delete NameIndex;
    delete DateIndex;
    delete fs;
}

// ─────────────────────────────────────────────────────────────────────────────
// Helper: write one output file
//   Line 1  : "Number of nodes traversed: N"
//   Lines 2+: one path per line (no trailing newline after last entry)
// ─────────────────────────────────────────────────────────────────────────────
static void writeOutput(const vector<int>& indices,
                        int                nodesVisited,
                        const string&      outputPath,
                        const FileSystem*  fsys) {
    ofstream out(outputPath);
    if (!out.is_open()) {
        cerr << "Cannot open: " << outputPath << "\n";
        return;
    }
    out << "Number of nodes traversed: " << nodesVisited << "\n";
    for (int idx : indices)
        out << fsys->entries[idx].path << "\n";
}

// ─────────────────────────────────────────────────────────────────────────────
// FindByName
//   Exact search in NameIndex; writes node count + matching paths.
// ─────────────────────────────────────────────────────────────────────────────
void FileExplorer::FindByName(const string& filename,
                               const string& output_path) {
    auto [indices, nodes] = NameIndex->Search(filename);
    writeOutput(indices, nodes, output_path, fs);
}

// ─────────────────────────────────────────────────────────────────────────────
// FindByDate
//   Exact search in DateIndex for files whose modifiedOn == date (YYYY-MM-DD).
// ─────────────────────────────────────────────────────────────────────────────
void FileExplorer::FindByDate(const string& date,
                               const string& output_path) {
    auto [indices, nodes] = DateIndex->Search(date);
    writeOutput(indices, nodes, output_path, fs);
}

// ─────────────────────────────────────────────────────────────────────────────
// FindByNameAndDate
//   Queries NameIndex AND DateIndex independently, writes their INTERSECTION.
//   Total node count = nameNodes + dateNodes (both traversals reported).
// ─────────────────────────────────────────────────────────────────────────────
void FileExplorer::FindByNameAndDate(const string& filename,
                                      const string& date,
                                      const string& output_path) {
    auto [nameIdx, nameNodes] = NameIndex->Search(filename);
    auto [dateIdx, dateNodes] = DateIndex->Search(date);

    sort(nameIdx.begin(), nameIdx.end());
    sort(dateIdx.begin(), dateIdx.end());

    vector<int> common;
    set_intersection(nameIdx.begin(), nameIdx.end(),
                     dateIdx.begin(), dateIdx.end(),
                     back_inserter(common));

    writeOutput(common, nameNodes + dateNodes, output_path, fs);
}

// ─────────────────────────────────────────────────────────────────────────────
// FindByNameAndSize
//   Searches by name, then filters results to exact size match.
//   Node count = name traversal only (size filter is a post-process).
// ─────────────────────────────────────────────────────────────────────────────
void FileExplorer::FindByNameAndSize(const string& filename,
                                      const int     size,
                                      const string& output_path) {
    auto [indices, nodes] = NameIndex->Search(filename);

    vector<int> filtered;
    for (int idx : indices)
        if (fs->entries[idx].Size == size)
            filtered.push_back(idx);

    writeOutput(filtered, nodes, output_path, fs);
}

// ─────────────────────────────────────────────────────────────────────────────
// FindFilesCreatedDuring
//   Pruned in-order range traversal on DateIndex for dates in [date1, date2].
//   Results are sorted by date (in-order traversal property); the node count
//   differs between BST and AVL, so the test ignores line 1 for this method.
// ─────────────────────────────────────────────────────────────────────────────
void FileExplorer::FindFilesCreatedDuring(const string& date1,
                                           const string& date2,
                                           const string& output_path) {
    auto [indices, nodes] = DateIndex->SearchRange(date1, date2);
    writeOutput(indices, nodes, output_path, fs);
}