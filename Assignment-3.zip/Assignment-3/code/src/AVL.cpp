// Provide your implementation for the AVLIndex class here
#include "AVL.hpp"
#include <algorithm>

AVLIndex::AVLIndex() : BSTIndex() {}

// Returns 0 for null, otherwise the node's height
int AVLIndex::getHeight(TreeNode* node) const {
    return node ? node->height : 0;
}

// Update stored height from children 
void AVLIndex::updateHeight(TreeNode* node) {
    if (node)
        node->height = 1 + max(getHeight(node->left), getHeight(node->right));
}

// Find the balance factor
int AVLIndex::getBalance(TreeNode* node) const {
    return node ? getHeight(node->left) - getHeight(node->right) : 0;
}

// Right rotation for balancing; when the left subtree is too tall, left child becomes the new root of subtree
TreeNode* AVLIndex::rotateRight(TreeNode* y) {
    TreeNode* x = y->left;
    TreeNode* B = x->right;
    x->right = y;
    y->left  = B;
    updateHeight(y);  // update lower node first
    updateHeight(x);
    return x;  // new subtree root
}

// Left rotation for balancing; when the right subtree is too tall
TreeNode* AVLIndex::rotateLeft(TreeNode* x) {
    TreeNode* y = x->right;
    TreeNode* B = y->left;
    y->left  = x;
    x->right = B;
    updateHeight(x);  // lower node updated first
    updateHeight(y);
    return y;  // new subtree root
}

TreeNode* AVLIndex::avlInsert(TreeNode* node, const string& key, int idx) {
    if (!node) return new TreeNode(key, idx); // normal BST insertion
    if (key < node->key) {
        node->left  = avlInsert(node->left,  key, idx);
    } else if (key > node->key) {
        node->right = avlInsert(node->right, key, idx);
    } else { // Duplicate key: add the index to the existing node
        node->indices.push_back(idx);
        return node;
    }
    updateHeight(node);
    int bal = getBalance(node); // rebalance if needed 
    // left subtree is heavy and new key inserted further left; single right rotation needed
    if (bal > 1 && key < node->left->key)
        return rotateRight(node);
    // right subtree is heavy and new key inserted further right; single left rotation needed 
    if (bal < -1 && key > node->right->key)
        return rotateLeft(node);
    // new key inserted into right subtree of left child; left rotate child, then right rotate node
    if (bal > 1 && key > node->left->key) {
        node->left = rotateLeft(node->left);
        return rotateRight(node);
    }
    // new key inserted into left subtree of right child; right rotate child, then left rotate node
    if (bal < -1 && key < node->right->key) {
        node->right = rotateRight(node->right);
        return rotateLeft(node);
    }
    return node;
} 

TreeNode* AVLIndex::insertNode(TreeNode* node, const string& key, int idx) {
    return avlInsert(node, key, idx);
}

void AVLIndex::Add(const int i, const string& Key) {
    root = avlInsert(root, Key, i);
}