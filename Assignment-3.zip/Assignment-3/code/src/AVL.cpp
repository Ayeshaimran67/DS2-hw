// Provide your implementation for the AVLIndex class here
#include "AVL.hpp"
#include <algorithm>

// ── Constructor ───────────────────────────────────────────────────────────────
AVLIndex::AVLIndex() : BSTIndex() {}

// ── Height helper ─────────────────────────────────────────────────────────────
// Returns 0 for null, otherwise the stored height field.
int AVLIndex::getHeight(TreeNode* node) const {
    return node ? node->height : 0;
}

// ── Update stored height from children ───────────────────────────────────────
void AVLIndex::updateHeight(TreeNode* node) {
    if (node)
        node->height = 1 + max(getHeight(node->left), getHeight(node->right));
}

// ── Balance factor = height(left subtree) - height(right subtree) ─────────────
// Positive → left-heavy, negative → right-heavy.
// AVL property requires this to stay in {-1, 0, +1} at all nodes.
int AVLIndex::getBalance(TreeNode* node) const {
    return node ? getHeight(node->left) - getHeight(node->right) : 0;
}

// ── Right rotation ────────────────────────────────────────────────────────────
// Used when the left subtree is too tall (LL and LR cases).
//
//        y                x
// (y left-child x becomes new root; x right-child becomes y left-child)
//      x   C    →       A   y
//
//    A   B                B   C
//
// x's right child (B) becomes y's new left child.
// y drops down to become x's right child.
// Heights updated bottom-up (y first since it's now lower).
TreeNode* AVLIndex::rotateRight(TreeNode* y) {
    TreeNode* x = y->left;
    TreeNode* B = x->right;

    x->right = y;
    y->left  = B;

    updateHeight(y);  // y is now lower; must be updated first
    updateHeight(x);

    return x;  // x is the new subtree root
}

// ── Left rotation ─────────────────────────────────────────────────────────────
// Used when the right subtree is too tall (RR and RL cases).
//
//      x                  y
//
//    A   y      →       x   C
//
//      B   C          A   B
//
TreeNode* AVLIndex::rotateLeft(TreeNode* x) {
    TreeNode* y = x->right;
    TreeNode* B = y->left;

    y->left  = x;
    x->right = B;

    updateHeight(x);  // x is now lower; must be updated first
    updateHeight(y);

    return y;  // y is the new subtree root
}

// ── AVL insertion (recursive) ─────────────────────────────────────────────────
// Step 1: Standard BST insertion (or duplicate append).
// Step 2: Update this node's height on the way back up.
// Step 3: Compute balance factor; if |balance| > 1, apply the appropriate fix.
TreeNode* AVLIndex::avlInsert(TreeNode* node, const string& key, int idx) {

    // ── Step 1: BST insert ──────────────────────────────────────────────
    if (!node) return new TreeNode(key, idx);

    if (key < node->key) {
        node->left  = avlInsert(node->left,  key, idx);
    } else if (key > node->key) {
        node->right = avlInsert(node->right, key, idx);
    } else {
        // Duplicate key: add the index to the existing node; tree stays balanced
        node->indices.push_back(idx);
        return node;
    }

    // ── Step 2: Update height ───────────────────────────────────────────
    updateHeight(node);

    // ── Step 3: Rebalance if needed ─────────────────────────────────────
    int bal = getBalance(node);

    // ── LL Case: left subtree is heavy AND new key went further left
    //    Fix: single right rotation
    if (bal > 1 && key < node->left->key)
        return rotateRight(node);

    // ── RR Case: right subtree is heavy AND new key went further right
    //    Fix: single left rotation
    if (bal < -1 && key > node->right->key)
        return rotateLeft(node);

    // ── LR Case: left subtree is heavy AND new key went into its right side
    //    Fix: left-rotate the left child first, then right-rotate this node
    if (bal > 1 && key > node->left->key) {
        node->left = rotateLeft(node->left);
        return rotateRight(node);
    }

    // ── RL Case: right subtree is heavy AND new key went into its left side
    //    Fix: right-rotate the right child first, then left-rotate this node
    if (bal < -1 && key < node->right->key) {
        node->right = rotateRight(node->right);
        return rotateLeft(node);
    }

    // Node is balanced; return unchanged
    return node;
}

// ── Override insertNode hook ──────────────────────────────────────────────────
TreeNode* AVLIndex::insertNode(TreeNode* node,
                                const string& key, int idx) {
    return avlInsert(node, key, idx);
}

// ── Override Add ─────────────────────────────────────────────────────────────
void AVLIndex::Add(const int i, const string& Key) {
    root = avlInsert(root, Key, i);
}