// Provide your implementation for the BSTIndex class here
#include "BST.hpp"

BSTIndex::BSTIndex() : root(nullptr) {}
BSTIndex::~BSTIndex() { destroy(root); }

// Recursively delete all nodes in the tree
void BSTIndex::destroy(TreeNode* node) {
    if (!node) return;
    destroy(node->left);
    destroy(node->right);
    delete node;
}

TreeNode* BSTIndex::insertNode(TreeNode* node, const string& key, int idx) {
    if (!node) return new TreeNode(key, idx);
    if (key < node->key)
        node->left  = insertNode(node->left,  key, idx);
    else if (key > node->key)
        node->right = insertNode(node->right, key, idx);
    else
        node->indices.push_back(idx);  
    return node;
}

void BSTIndex::CreateIndex(vector<FileSystemEntry>& Data, const string& IndexType) {
    for (int i = 0; i < static_cast<int>(Data.size()); ++i) {
        string key;
        if (IndexType == "FileName")
            key = Data[i].Filename;
        else  // lastModifiedOn - already in YYYY-MM-DD format
            key = Data[i].modifiedOn;
        Add(i, key);
    }
}

void BSTIndex::Add(const int i, const string& Key) {
    root = insertNode(root, Key, i); // key-index pair insertion
}

pair<vector<int>, int> BSTIndex::Search(const string& Key) const {
    vector<int> result;
    int nodesVisited = 0;
    TreeNode* curr = root;
    while (curr) {
        ++nodesVisited;
        if (Key == curr->key) {
            result = curr->indices;
            break;
        } else if (Key < curr->key) {
            curr = curr->left;
        } else {
            curr = curr->right;
        }
    }
    return {result, nodesVisited};
}

void BSTIndex::collectRange(TreeNode* node, const string& lo, const string& hi, vector<int>& results, int& nodesVisited) const {
    if (!node) return;
    ++nodesVisited;
    if (node->key > lo) // Traverse left subtree
        collectRange(node->left, lo, hi, results, nodesVisited);
    if (node->key >= lo && node->key <= hi) // Include current node if in range
        for (int idx : node->indices)
            results.push_back(idx);
    if (node->key < hi) // Traverse right subtree
        collectRange(node->right, lo, hi, results, nodesVisited);
}

pair<vector<int>, int> BSTIndex::SearchRange(const string& lo,const string& hi) const {
    vector<int> results;
    int nodesVisited = 0;
    collectRange(root, lo, hi, results, nodesVisited);
    return {results, nodesVisited};
}