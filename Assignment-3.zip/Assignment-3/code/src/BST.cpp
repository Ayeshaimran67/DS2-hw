// Provide your implementation for the BSTIndex class here
#include "BST.hpp"

// ── Constructor / Destructor ──────────────────────────────────────────────────
BSTIndex::BSTIndex() : root(nullptr) {}

BSTIndex::~BSTIndex() { destroy(root); }

void BSTIndex::destroy(TreeNode* node) {
    if (!node) return;
    destroy(node->left);
    destroy(node->right);
    delete node;
}

// ── Internal BST insertion ────────────────────────────────────────────────────
// Returns the (possibly new) root of the subtree after inserting (key, idx).
// Duplicate keys: append idx to the existing node's indices – no new node.
TreeNode* BSTIndex::insertNode(TreeNode* node, const string& key, int idx) {
    if (!node) return new TreeNode(key, idx);

    if (key < node->key)
        node->left  = insertNode(node->left,  key, idx);
    else if (key > node->key)
        node->right = insertNode(node->right, key, idx);
    else
        node->indices.push_back(idx);  // duplicate: store another file index

    return node;
}

// ── CreateIndex ───────────────────────────────────────────────────────────────
// Iterates over Data and calls Add(i, key) for each entry.
// IndexType == "FileName"       → key is entry.Filename
// IndexType == "lastModifiedOn" → key is entry.modifiedOn  (already YYYY-MM-DD)
void BSTIndex::CreateIndex(vector<FileSystemEntry>& Data,
                            const string& IndexType) {
    for (int i = 0; i < static_cast<int>(Data.size()); ++i) {
        string key;
        if (IndexType == "FileName")
            key = Data[i].Filename;
        else  // "lastModifiedOn" – FileSystem::ParseTimestamp already gave us YYYY-MM-DD
            key = Data[i].modifiedOn;
        Add(i, key);
    }
}

// ── Add ───────────────────────────────────────────────────────────────────────
void BSTIndex::Add(const int i, const string& Key) {
    root = insertNode(root, Key, i);
}

// ── Search (exact key) ────────────────────────────────────────────────────────
// Iterative traversal; counts every node touched.
// Returns {indices of matching records, total nodes visited}.
pair<vector<int>, int> BSTIndex::Search(const string& Key) const {
    vector<int> result;
    int nodesVisited = 0;
    TreeNode* curr = root;

    while (curr) {
        ++nodesVisited;
        if (Key == curr->key) {
            result = curr->indices;
            break;
        } else if (Key < curr->key) {
            curr = curr->left;
        } else {
            curr = curr->right;
        }
    }
    return {result, nodesVisited};
}

// ── In-order range traversal with pruning ─────────────────────────────────────
// Visits nodes in sorted key order (left → current → right), pruning subtrees
// that cannot contribute any key in [lo, hi]:
//   • node->key < lo  → left subtree also < lo, skip it; only recurse right
//   • node->key > hi  → right subtree also > hi, skip it; only recurse left
//   • lo ≤ key ≤ hi   → collect all indices, recurse both sides
//
// Because we always go left before right (in-order), results come out sorted
// by key regardless of whether the tree is balanced or not.  This means BST
// and AVL produce paths in the same order, which is required by the test.
void BSTIndex::collectRange(TreeNode* node, const string& lo, const string& hi,
                             vector<int>& results, int& nodesVisited) const {
    if (!node) return;
    ++nodesVisited;

    // Recurse left first (in-order), but only if the left subtree can hold
    // keys >= lo  (all left-subtree keys < node->key, so skip if key <= lo)
    if (node->key > lo)
        collectRange(node->left, lo, hi, results, nodesVisited);

    // Collect current node if its key is within [lo, hi]
    if (node->key >= lo && node->key <= hi)
        for (int idx : node->indices)
            results.push_back(idx);

    // Recurse right, but only if the right subtree can hold keys <= hi
    // (all right-subtree keys > node->key, so skip if key >= hi)
    if (node->key < hi)
        collectRange(node->right, lo, hi, results, nodesVisited);
}

// ── SearchRange ───────────────────────────────────────────────────────────────
pair<vector<int>, int> BSTIndex::SearchRange(const string& lo,
                                              const string& hi) const {
    vector<int> results;
    int nodesVisited = 0;
    collectRange(root, lo, hi, results, nodesVisited);
    return {results, nodesVisited};
}