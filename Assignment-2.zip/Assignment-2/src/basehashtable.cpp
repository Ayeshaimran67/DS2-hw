#include "basehashtable.hpp"

BaseHashTable::BaseHashTable(size_t cap) : capacity(cap), size(0) {
    table.resize(capacity);
}

int BaseHashTable::hash_fn(int key) const {
    return key % capacity;
}

double BaseHashTable::getAvgProbeLength() const {
    if (size == 0) return 0.0;
 
    double total = 0.0;
    for (size_t i = 0; i < table.size(); i++) {
        if (table[i].occupied) { // average probe distance across all occupied slots
            total += table[i].probeDistance; 
        }
    }
    return total / size;
}

int BaseHashTable::getMaxProbeLength() const {
    int maxLen = 0;
    for (size_t i = 0; i < table.size(); i++) {
        if (table[i].occupied) { // maximum probe distance across all occupied slots
            maxLen = std::max(maxLen, static_cast<int>(table[i].probeDistance));
        }  
    }
    return maxLen;
}

std::map<int, int> BaseHashTable::getProbeDistribution() const {
    std::map<int, int> dist; // key = probe dist d, value = num of keys at d slots from home
    for (size_t i = 0; i < table.size(); i++) {
        if (table[i].occupied) {
            dist[table[i].probeDistance]++; // increment count for this dist
        }
    }
    return dist;
}