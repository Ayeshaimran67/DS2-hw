#include "basehashtable.hpp"

BaseHashTable::BaseHashTable(size_t cap) : capacity(cap), size(0) {
    table.resize(capacity);
}

int BaseHashTable::hash_fn(int key) const {
    return key % capacity;
}

double BaseHashTable::getAvgProbeLength() const {
    if (size == 0) return 0.0;
 
    double total = 0.0;
    for (size_t i = 0; i < table.size(); i++) {
        if (table[i].occupied) {
            total += table[i].probeDistance;
        }
    }
    return total / size;
}

int BaseHashTable::getMaxProbeLength() const {
    int maxLen = 0;
    for (size_t i = 0; i < table.size(); i++) {
        if (table[i].occupied) {
            maxLen = std::max(maxLen, static_cast<int>(table[i].probeDistance));
        }  
    }
    return maxLen;
}

std::map<int, int> BaseHashTable::getProbeDistribution() const {
    std::map<int, int> dist;
    for (size_t i = 0; i < table.size(); i++) {
        if (table[i].occupied) {
            dist[table[i].probeDistance]++;
        }
    }
    return dist;
}