#include "robinhood.hpp"

RobinHoodTable::RobinHoodTable(size_t size) : BaseHashTable(size) {}

bool RobinHoodTable::insert(int key) {
    if (size >= capacity) return false;
 
    // Before inserting, check for duplicates with a search
    {
        int probe;
        if (search(key, probe)) return false;
    }
 
    int    incomingKey  = key;
    size_t incomingDist = 0;
    size_t home         = static_cast<size_t>(hash_fn(key));
    size_t startPos     = home;
 
    for (size_t i = 0; i < capacity; i++) {
        size_t pos = (startPos + i) % capacity;
 
        if (!table[pos].occupied) {
            // Case (a): empty slot – place incoming key 
            table[pos].key           = incomingKey;
            table[pos].occupied      = true;
            table[pos].probeDistance = incomingDist;
            size++;
            return true;
 
        } else if (table[pos].probeDistance < incomingDist) {
            // Case (b): Robin Hood swap 
            std::swap(incomingKey,  table[pos].key);
            std::swap(incomingDist, table[pos].probeDistance);
        }
        // Case (c) – no swap; incoming key keeps searching
        incomingDist++;
    }
 
    return false;  // table full 
}

bool RobinHoodTable::search(int key, int& probeCount) const {
    size_t home = static_cast<size_t>(hash_fn(key));
    size_t startPos = home;
    probeCount = 0;
 
    for (size_t i = 0; i < capacity; i++) {
        size_t pos = (startPos + i) % capacity;
        probeCount++;
 
        if (!table[pos].occupied || table[pos].probeDistance < i) {
            // Empty slot: key is not present or
            // If the resident's probe distance is less than i, the key would have displaced the resident during insertion so key is not present
            return false;
        }
 
        if (table[pos].key == key) {
            // Found
            return true;
        }
    }
 
    return false;
}

bool RobinHoodTable::remove(int key) {
    size_t home = static_cast<size_t>(hash_fn(key));
 
    // Step 1: find the slot holding `key` 
    size_t del = capacity;
    for (size_t i = 0; i < capacity; i++) {
        size_t pos = (home + i) % capacity;
 
        if (!table[pos].occupied) {
            return false;  // empty slot; key absent
        }
 
        // key would have displaced a shorter-distance resident during insertion, so it cannot be here
        if (table[pos].probeDistance < i) {
            return false;
        }
 
        if (table[pos].key == key) {
            del = pos;
            break;
        }
    }
    if (del == capacity) return false;
 
    // Step 2: backward-shift 
    while (true) {
        size_t next = (del + 1) % capacity;
 
        // Stop if next slot is empty
        if (!table[next].occupied) break;
 
        // Stop if the next key is at its home position
        if (table[next].probeDistance == 0) break;
 
        // Shift the key at `next` one step back into the vacancy `del`
        table[del] = table[next];
        table[del].probeDistance--;  // one closer to home now
 
        del = next;
    }
 
    // Step 3: clear the final vacancy 
    table[del].occupied      = false;
    table[del].key           = 0;
    table[del].probeDistance = 0;
    size--;
 
    return true;
}