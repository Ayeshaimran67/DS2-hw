#include "robinhood.hpp"

RobinHoodTable::RobinHoodTable(size_t size) : BaseHashTable(size) {}

bool RobinHoodTable::insert(int key) {
    if (size >= capacity) return false;
 
    {
        int probe;
        if (search(key, probe)) return false; // duplicate search
    }
 
    int incomingKey = key;
    size_t incomingDist = 0;
    size_t home = static_cast<size_t>(hash_fn(key));
    size_t startPos = home;
 
    for (size_t i = 0; i < capacity; i++) {
        size_t pos = (startPos + i) % capacity;
 
        if (!table[pos].occupied) { // empty slot
            table[pos].key = incomingKey;
            table[pos].occupied = true;
            table[pos].probeDistance = incomingDist;
            size++;
            return true;
 
        } else if (table[pos].probeDistance < incomingDist) { // swap
            std::swap(incomingKey, table[pos].key);
            std::swap(incomingDist, table[pos].probeDistance);
        }
        incomingDist++;
    }
 
    return false;  // table full 
}

bool RobinHoodTable::search(int key, int& probeCount) const {
    size_t home = static_cast<size_t>(hash_fn(key));
    size_t startPos = home;
    probeCount = 0;
 
    for (size_t i = 0; i < capacity; i++) {
        size_t pos = (startPos + i) % capacity;
        probeCount++;
 
        if (!table[pos].occupied || table[pos].probeDistance < i) {
            // empty slot or
            // key would have displaced a shorter-distance resident during insertion, so its not present
            return false;
        }
 
        if (table[pos].key == key) {
            return true;
        }
    }
 
    return false;
}

bool RobinHoodTable::remove(int key) {
    size_t home = static_cast<size_t>(hash_fn(key));
 
    size_t del = capacity;
    for (size_t i = 0; i < capacity; i++) {
        size_t pos = (home + i) % capacity;
 
        if (!table[pos].occupied) {
            return false;  // empty slot
        }
 
        if (table[pos].probeDistance < i) { // key would have displaced a shorter-distance resident during insertion, so its not present
            return false;
        }
 
        if (table[pos].key == key) {
            del = pos;
            break;
        }
    }
    if (del == capacity) return false;
 
    while (true) { // backward - shift
        size_t next = (del + 1) % capacity;

        if (!table[next].occupied) break; 
 
        if (table[next].probeDistance == 0) break;
 
        table[del] = table[next];
        table[del].probeDistance--; 
 
        del = next;
    }
 
    table[del].occupied = false;
    table[del].key = 0;
    table[del].probeDistance = 0;
    size--;
 
    return true;
}