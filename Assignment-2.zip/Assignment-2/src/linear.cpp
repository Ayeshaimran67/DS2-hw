#include "linear.hpp"

LinearProbingTable::LinearProbingTable(size_t size) : BaseHashTable(size) {}

bool LinearProbingTable::insert(int key) {
    // Table full – cannot insert
    if (size >= capacity) return false;
 
    size_t home = static_cast<size_t>(hash_fn(key));   // ideal slot for this key
    size_t dist = 0;              // dist away from home
 
    for (size_t i = 0; i < capacity; i++) {
        // Current probe position (wrap-around)
        size_t pos = (home + i) % capacity;
 
        if (!table[pos].occupied) {
            // Empty slot found: place key here 
            table[pos].key           = key;
            table[pos].occupied      = true;
            table[pos].probeDistance = dist;
            size++;
            return true;
 
        } else if (table[pos].key == key) {
            // Duplicate key: do not insert 
            return false;
        }
 
        // Slot is occupied by a different key; advance
        dist++;
    }

    return false;
}

bool LinearProbingTable::search(int key, int& probeCount) const {
    size_t home = static_cast<size_t>(hash_fn(key));
    probeCount = 0;
 
    for (size_t i = 0; i < capacity; i++) {
        size_t pos = (home + i) % capacity;
        probeCount++;  
 
        if (!table[pos].occupied) {
            // Empty slot i.e key is not in the table
            return false;
 
        } else if (table[pos].key == key) {
            // Found
            return true;
        }
        // Occupied by a different key so keep probing
    }
 
    return false;  // full wrap without finding it
}

bool LinearProbingTable::remove(int key) {
    size_t home = static_cast<size_t>(hash_fn(key));
 
    // Step 1: locate the key 
    size_t del = capacity;  // index of the slot to delete
    for (size_t i = 0; i < capacity; i++) {
        size_t pos = (home + i) % capacity;
 
        if (!table[pos].occupied) {
            return false;  // empty slot before finding key
        }
        if (table[pos].key == key) {
            del = pos;
            break;
        }
    }
    if (del == capacity) return false;  // not found
 
    // Step 2: backward-shift 
    while (true) {
        // Next slot after the current vacancy
        size_t next = (del + 1) % capacity;
 
        // Empty so nothing left to shift
        if (!table[next].occupied) break;
 
        // If the next key is already at its home (probe distance 0), it cannot be moved back without violating correctness
        if (table[next].probeDistance == 0) break;
 
        // Shift the key at `next` into the vacancy at `del`
        table[del] = table[next];
        table[del].probeDistance--;  // it is now one step closer to home
 
        del = next;  // the vacancy has moved one step forward
    }
 
    // Step 3: clear the final vacancy 
    table[del].occupied      = false;
    table[del].key           = 0;
    table[del].probeDistance = 0;
    size--;
 
    return true;
}