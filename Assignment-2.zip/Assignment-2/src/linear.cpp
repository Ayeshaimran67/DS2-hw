#include "linear.hpp"

LinearProbingTable::LinearProbingTable(size_t size) : BaseHashTable(size) {}

bool LinearProbingTable::insert(int key) {
    if (size >= capacity) return false; // table is full
 
    size_t home = static_cast<size_t>(hash_fn(key)); // ideal slot for the key
    size_t dist = 0; // dist from home
 
    for (size_t i = 0; i < capacity; i++) {
        size_t pos = (home + i) % capacity; // curr probe position
 
        if (!table[pos].occupied) { // empty slot  
            table[pos].key = key;
            table[pos].occupied = true;
            table[pos].probeDistance = dist;
            size++;
            return true;
 
        } else if (table[pos].key == key) { // duplicate key; no insertion
            return false;
        }
 
        dist++; // slot is occupied 
    }

    return false;
}

bool LinearProbingTable::search(int key, int& probeCount) const {
    size_t home = static_cast<size_t>(hash_fn(key));
    probeCount = 0;
 
    for (size_t i = 0; i < capacity; i++) {
        size_t pos = (home + i) % capacity;
        probeCount++;  
 
        if (!table[pos].occupied) { // empty slot i.e key is not in the table
            return false;
 
        } else if (table[pos].key == key) {
            return true;
        }
    }
 
    return false;  // not found after full traversal 
}

bool LinearProbingTable::remove(int key) {
    size_t home = static_cast<size_t>(hash_fn(key));

    size_t del = capacity;  // slot to delete
    for (size_t i = 0; i < capacity; i++) {
        size_t pos = (home + i) % capacity;
 
        if (!table[pos].occupied) {
            return false;  // empty slot
        }
        if (table[pos].key == key) {
            del = pos;
            break;
        }
    }
    if (del == capacity) return false;  // not found

    while (true) { // backward - shifting
        size_t next = (del + 1) % capacity; // slot after the del one

        if (!table[next].occupied) break; // empty
 
        if (table[next].probeDistance == 0) break; // key at home; no shifting
 
        table[del] = table[next]; // shift key at next to del
        table[del].probeDistance--;  // closer to home so dist reduces
 
        del = next; 
    }
 
    table[del].occupied = false; // final empty slot cleared
    table[del].key = 0;
    table[del].probeDistance = 0;
    size--;
 
    return true;
}